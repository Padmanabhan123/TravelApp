package com.example.travel.model

data class TopPlacesData(
    var placeName: String,
    var countryName: String,
    var price: String,
    var imageUrl: Int
)
