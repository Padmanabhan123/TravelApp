package com.example.travel.model

data class RecentsData(
    var placeName: String,
    var countryName: String,
    var price: String,
    var imageUrl: Int
)
